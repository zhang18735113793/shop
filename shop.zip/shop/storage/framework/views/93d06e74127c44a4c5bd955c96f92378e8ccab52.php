<?php $__env->startSection('title','buycar'); ?>
<?php $__env->startSection('content'); ?>
<body id="loadingPicBlock" class="g-acc-bg">
    <input name="hidUserID" type="hidden" id="hidUserID" value="-1" />
    <div>
        <!--首页头部-->
        <div class="m-block-header">
            <a href="/" class="m-public-icon m-1yyg-icon"></a>
            <a href="/" class="m-index-icon">编辑</a>
        </div>
        <!--首页头部 end-->
        <div class="g-Cart-list">
            <ul id="cartBody">
                <?php $__currentLoopData = $goods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <s class="xuan current"></s>
                    <a class="fl u-Cart-img" href="<?php echo e(url('IndexController/shopcontent')); ?>/<?php echo e($v->goods_id); ?>">
                        <img src="/uploads/<?php echo e($v->goods_img); ?>" border="0" alt="">
                    </a>
                    <div class="u-Cart-r">
                        <a href="<?php echo e(url('IndexController/shopcontent')); ?>/<?php echo e($v->goods_id); ?>" class="gray6"><?php echo e($v->goods_name); ?></a>
                        <span class="gray9">
                            <em>剩余124人次</em>
                        </span>
                        <div class="num-opt" goods_id="<?php echo e($v->goods_id); ?>">
                            <em class="num-mius dis min"><i></i></em>
                            <input class="text_box" name="num" maxlength="6" type="text" value="<?php echo e($v->buy_num); ?>" codeid="12501977">
                            <em class="num-add add"><i></i></em>
                        </div>
                        <a href="javascript:;" name="delLink" cid="12501977" isover="0" class="z-del"><s class="delcart" goods_id="<?php echo e($v->goods_id); ?>"></s></a>
                    </div>    
                </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <div id="divNone" class="empty "  style="display: none"><s></s><p>您的购物车还是空的哦~</p><a href="https://m.1yyg.com" class="orangeBtn">立即潮购</a></div>
        </div>
        <div id="mycartpay" class="g-Total-bt g-car-new" style="">
            <dl>
                <dt class="gray6">
                    <s class="quanxuan current"></s>全选
                    <p class="money-total">合计<em class="orange "><span>￥<?php echo e($price); ?></span></em></p>

                </dt>
                <dd>
                    <a href="javascript:;" id="a_payment" class="orangeBtn w_account remove">删除</a>
                    <a href="javascript:;" id="a_payment" class="orangeBtn w_account">去结算</a>
                </dd>
            </dl>
        </div>
        <div class="hot-recom">
            <div class="title thin-bor-top gray6">
                <span><b class="z-set"></b>人气推荐</span>
                <em></em>
            </div>
            <div class="goods-wrap thin-bor-top">
                <ul class="goods-list clearfix">
                    <?php $__currentLoopData = $sendgoods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e(url('IndexController/shopcontent')); ?>/<?php echo e($v->goods_id); ?>" class="g-pic">
                            <img src="/uploads/<?php echo e($v->goods_img); ?>" width="136" height="136">
                        </a>
                        <p class="g-name">
                            <a href="<?php echo e(url('IndexController/shopcontent')); ?>/<?php echo e($v->goods_id); ?>"><?php echo e($v->goods_name); ?></a>
                        </p>
                        <ins class="gray9">价值:￥<?php echo e($v->self_price); ?></ins>
                        <div class="btn-wrap">
                            <div class="Progress-bar">
                                <p class="u-progress">
                                    <span class="pgbar" style="width:1%;">
                                        <span class="pging"></span>
                                    </span>
                                </p>
                            </div>
                            <div class="gRate" goods_id="<?php echo e($v->goods_id); ?>" data-productid="23458">
                                <a href="javascript:;"><s></s></a>
                            </div>
                        </div>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>


        <input type="hidden" name="_token" id="_token" value="<?php echo csrf_token()?>">

<div class="footer clearfix">
    <ul>
        <li class="f_home"><a href="<?php echo e(url('/')); ?>" ><i></i>潮购</a></li>
        <li class="f_single"><a href="/v41/post/index.do" ><i></i>晒单</a></li>
        <li class="f_car"><a id="btnCart" href="<?php echo e(url('IndexController/buycar')); ?>" class="hover"><i></i>购物车</a></li>
        <li class="f_personal"><a href="<?php echo e(url('IndexController/userpage')); ?>" ><i></i>我的潮购</a></li>
    </ul>
</div>



</body>
</html>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('my-js'); ?>
    <!---商品加减算总数---->
    <script type="text/javascript">

    </script>
    <script>

        // 全选
        $(".quanxuan").click(function () {
            if($(this).hasClass('current')){
                $(this).removeClass('current');

                $(".g-Cart-list .xuan").each(function () {
                    if ($(this).hasClass("current")) {
                        $(this).removeClass("current");
                    } else {
                        $(this).addClass("current");
                    }
                });
                GetCount();
            }else{
                $(this).addClass('current');

                $(".g-Cart-list .xuan").each(function () {
                    $(this).addClass("current");
                    // $(this).next().css({ "background-color": "#3366cc", "color": "#ffffff" });
                });
                GetCount();
            }


        });
        // 单选
        $(".g-Cart-list .xuan").click(function () {
            if($(this).hasClass('current')){


                $(this).removeClass('current');

            }else{
                $(this).addClass('current');
            }
            if($('.g-Cart-list .xuan.current').length==$('#cartBody li').length){
                $('.quanxuan').addClass('current');

            }else{
                $('.quanxuan').removeClass('current');
            }
            // $("#total2").html() = GetCount($(this));
            GetCount();
            //alert(conts);
        });
        // 已选中的总额
        function GetCount() {
            var conts = 0;
            var aa = 0;
            $(".g-Cart-list .xuan").each(function () {
                if ($(this).hasClass("current")) {
                    for (var i = 0; i < $(this).length; i++) {
                        conts += parseInt($(this).parents('li').find('input.text_box').val());
                        // aa += 1;
                    }
                }
            });

            $(".total").html('<span>￥</span>'+(conts).toFixed(2));
        }
        GetCount();
    </script>
    <script>
        $(function(){
            layui.use('layer',function(){
                var layer=layui.layer;
                var _token=$('#_token').val();
                $(".add").click(function () {
                    var t = $(this).prev();
                    t.val(parseInt(t.val()) + 1);
                    var num=t.val();
                    var goods_id=$(this).parent('div').attr('goods_id');
                    $.post(
                        "<?php echo e(url('IndexController/updatecart')); ?>",
                        {num:num,goods_id:goods_id,_token:_token},
                        function(res){

                        }
                    )
                })
                $(".min").click(function () {
                    var t = $(this).next();
                    if(t.val()>1){
                        t.val(parseInt(t.val()) - 1);
                        var num=t.val();
                        var goods_id=$(this).parent('div').attr('goods_id');
                        $.post(
                            "<?php echo e(url('IndexController/updatecart')); ?>",
                            {num:num,goods_id:goods_id,_token:_token},
                            function(res){

                            }
                        )
                    }
                })
                $(document).on('click','.gRate',function(){
                    var goods_id=$(this).attr('goods_id');
                    var _token=$('#_token').val();
                    $.post(
                        "<?php echo e(url('IndexController/cartadd')); ?>",
                        {goods_id:goods_id,_token:_token},
                        function(res){
                            if(res==1){
                                layer.msg('添加购物车成功',{icon:1,time:3000},function(){
                                    history.go(0);
                                })
                            }else if(res==2){
                                layer.msg('添加购物车失败',{icon:2})
                            }else if(res==3){
                                layer.msg('请先登录',{icon:2,time:3000},function(){
                                    location.href="<?php echo e(url('IndexController/login')); ?>"
                                })
                            }
                        }
                    )
                })
                $(document).on('click','.delcart',function(){
                    var goods_id=$(this).attr('goods_id');
                    var _token=$('#_token').val();
                    $.post(
                        "<?php echo e(url('IndexController/delcart')); ?>",
                        {goods_id:goods_id,_token:_token},
                        function(res){
                           if(res==1){
                               layer.msg('删除成功',{icon:1,time:3000},function(){
                                   history.go(0);
                               })
                           }else{
                               layer.msg('删除失败',{icoon:2})
                           }
                        }
                    )
                })
            })
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('must', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>